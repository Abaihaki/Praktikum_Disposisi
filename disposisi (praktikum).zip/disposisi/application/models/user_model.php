<?php defined('BASEPATH') OR exit ('No direct script acces allowed');
class user_model extends CI_model
{
    protected $_table = 'tb_user';
    protected $primary = 'id';

    public function GetAll()
    {
        return $this->db->where('is_active',1)->get($this->_table)->result()
}
    
    public function save(){
        $data = array(){
            'username' => htmlspecialchars($this->input->post('username'),true),
            'password' => htmlspecialchars ($this->input->post('password'),PASSWORD_DEFAULT),
             'email' => htmlspecialchars($this->input->post('email'),true),
              'full_name' => htmlspecialchars($this->input->post('full_name'),true),
               'phone' => htmlspecialchars($this->input->post('phone'),true),
                'role' => htmlspecialchars($this->input->post('role'),true),
                'is_active' =>1,
        );

    }

       